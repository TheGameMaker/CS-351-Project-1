//Clark Smiley
//G00891966
//CircleBrush.h
//
// The header file for Point Brush. 
//

#ifndef CIRCLEBRUSH_H
#define CIRCLERUSH_H

#include "ImpBrush.h"

class CircleBrush : public ImpBrush
{
public:
	CircleBrush(ImpressionistDoc* pDoc = NULL, char* name = NULL);

	void drawCircle(const Point source, const Point target);
	void BrushBegin(const Point source, const Point target);
	void BrushMove(const Point source, const Point target);
	void BrushEnd(const Point source, const Point target);
	char* BrushName(void);
};

#endif