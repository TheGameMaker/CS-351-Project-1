Clark Smiley G00891966
save.bmp is the artifact file

I added my picture of mason to the images, but it would not load the bit map into the program for some reason.

I modified the point brush to draw lines in the line brush class by drawing 2 vertices:

	one at target x and y

	and the other at target x + change in x and target y + change in y

I then used this method to draw scattered lines at different target X's and Y's

I also modified the point brush to draw a circle around target x and y.  I then used this method to draw a random amount of circles with different
target X's and Y's to do the scattered circles.  I could not get the circle to draw point by point so I just commented it out.

I also had to modify the ImpressionistDoc and the ImpressionistUI so it pointed to the correct brush classes instead
of the default pointbrush class.I went on to make the angle,thickness and alpha sliders and a menu item for the brush stroke direction, and a button for the gaussian blur.

For the blur I used a 3x3 kernel matrix of 1 2 1
					   2 4 2
					   1 2 1

