//Clark Smiley
//G00891966
// CircleBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "CircleBrush.h"
#include "math.h"

#define PI 3.14159265

extern float frand();

CircleBrush::CircleBrush(ImpressionistDoc* pDoc, char* name) :
	ImpBrush(pDoc, name)
{
}

//draws a circle
void CircleBrush::drawCircle(const Point source, const Point target) {
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int size = pDoc->getSize();
	int radius = (size / 2);
	GLubyte alpha = pDoc->getAlpha();
	double twoPi = 2.0 * PI;
	int radsq = radius * radius;
	int tar_startX = target.x - (size / 2);
	int tar_startY = target.y - (size / 2);
	int src_startX = source.x - (size / 2);
	int src_startY = source.y - (size / 2);
	int centerX = radius;
	int centerY = radius;
	Point newTarget, newSource;
	unsigned char* mask = new unsigned char[size * size];
	memset(mask, 0, size * size);

	//This code was made to draw a circle point by point. for some reason neither of the if statements below work, but they have a cool effect.
	//for (int a = 0; a < size; a++) {
		//for (int b = 0; b < size; b++) {
			//if (((a - target.x) ^ 2 + (b - target.y) ^ 2) <= radsq) {
			//if (((a - centerX) *(a - centerX) + (b - centerY)*(b - centerY)) <= radsq) {
				//mask[b*size + a] = 1;  
			//}
		//}
	//}

	//for (int k = 0; k < size; k++) {
		//for (int p = 0; p < size; p++) {
			//newTarget = Point(tar_startX + k, tar_startY + p);
			//newSource = Point(src_startX + k, src_startY + p);
			//SetColor(newSource, newTarget, alpha, mask[(p*size) + k]);
			//glVertex2d(tar_startX + k, tar_startY + p);
		//}
	//}
	
	glVertex2f(target.x, target.y);
	for (int i = 0; i <= 20; i++) {
		glVertex2f((target.x + (radius * cos(i * twoPi / 20))), (target.y + (radius * sin(i * twoPi / 20))));
	}
}
void CircleBrush::BrushBegin(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int size = pDoc->getSize();

	glPointSize((float)size);

	BrushMove(source, target);
}

void CircleBrush::BrushMove(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int radius = (pDoc->getSize()/2);
	GLubyte alpha = pDoc->getAlpha();
	double twoPi = 2.0 * PI;

	if (pDoc == NULL) {
		printf("CircleBrush::BrushMove  document is NULL\n");
		return;
	}

	glBegin(GL_TRIANGLE_FAN);
	//glEnable(GL_BLEND);
	SetColor(source);
	drawCircle(source, target);

	glEnd();
}

void CircleBrush::BrushEnd(const Point source, const Point target)
{
	// do nothing so far
}