//
// PointBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "pointbrush.h"

extern float frand();

PointBrush::PointBrush( ImpressionistDoc* pDoc, char* name ) :
	ImpBrush(pDoc,name)
{
}

void PointBrush::BrushBegin( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = 1;



	glPointSize(1);

	BrushMove( source, target );
}

void PointBrush::BrushMove( const Point source, const Point target )
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg=pDoc->m_pUI;

	int size = pDoc->getSize();
	int imageWidth = pDoc->m_nWidth;
	GLubyte alpha = pDoc->getAlpha();
	int tar_startX = target.x - (size/2);
	int tar_startY = target.y - (size/2);
	Point newTarget;

	unsigned char* mask = new unsigned char[size * size];
	memset(mask, 1, size * size);

	//pDoc->m_pPaintBitstart = Point((((centerMaskY * size) + centerMaskX) * 3) + mask);

	glColor3i(255, 0, 0);
	glVertex2d(source.x, source.y);
	dlg->m_origView->refresh();

	

	if ( pDoc == NULL ) {
		printf( "PointBrush::BrushMove  document is NULL\n" );
		return;
	}

	glBegin( GL_POINTS );
	//draws the points pixel by pixel and applies the alpha to each pixel
	for (int k = 0; k < size; k++) {
		for (int p = 0; p < size; p++) {
			newTarget = Point(tar_startX+k, tar_startY+p);
			SetColor(source, newTarget, alpha, mask[(p*size) + k]);
			glVertex2d(tar_startX + k, tar_startY + p);
		}
	}

	glEnd();
}

void PointBrush::BrushEnd( const Point source, const Point target )
{
	// do nothing so far
}

