// 
// impressionistDoc.h
//
// header file for Doc 
//

#ifndef ImpressionistDoc_h
#define ImpressionistDoc_h

#include "impressionist.h"
#include "bitmap.h"

class ImpressionistUI;

class ImpressionistDoc 
{
public:
	ImpressionistDoc();

	void	setUI(ImpressionistUI* ui);		// Assign the UI to use

	int		loadImage(char *iname);			// called by the UI to load image
	int		saveImage(char *iname);			// called by the UI to save image


	int     clearCanvas();                  // called by the UI to clear the drawing canvas
	int gaussBlur();
	void	setBrushType(int type);			// called by the UI to set the brushType
	int		getSize();						// get the UI size
	int getAngle();
	int getThickness();
	GLubyte getAlpha();
	void	setSize(int size);				// set the UI size
	void setAngle(int angle);
	void setThickness(int thickness);
	void setAlpha(GLubyte alpha);
	char*	getImageName();					// get the current image name
	

// Attributes
public:
	// Dimensions of original window.
	int				m_nWidth, 
					m_nHeight;
	// Dimensions of the paint window.
	int				m_nPaintWidth, 
					m_nPaintHeight;	
	//Dimensions of the mask
	int m_nMaskWidth,
		m_nMaskHeight;
	// Bitmaps for original image and painting.
	unsigned char*	m_ucBitmap;
	unsigned char*	m_ucPainting;


	// The current active brush.
	ImpBrush*			m_pCurrentBrush;	
	// Size of the brush.
	int m_nSize;
	int m_nAngle;
	int m_nThickness;
	GLubyte m_nAlpha;

	ImpressionistUI*	m_pUI;

// Operations
public:
	// Get the color of the original picture at the specified coord
	GLubyte* GetOriginalPixel( int x, int y );   
	GLubyte* GetTargetPixel(int x, int y);
	// Get the color of the original picture at the specified point	
	GLubyte* GetOriginalPixel( const Point p );  
	GLubyte* GetTargetPixel(const Point t);


private:
	char			m_imageName[256];

};

extern void MessageBox(char *message);

#endif
