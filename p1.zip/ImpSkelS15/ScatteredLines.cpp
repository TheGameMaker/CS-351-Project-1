//Clark Smiley
//G00891966
// LineBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredLines.h"
#include "math.h"

#define PI 3.14159265

extern float frand();

ScatteredLinesBrush::ScatteredLinesBrush(ImpressionistDoc* pDoc, char* name) :
	ImpBrush(pDoc, name)
{
}

//draws a line
void ScatteredLinesBrush::drawLine(const Point source, const Point target) {
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int maxSize = pDoc->getSize();
	int angle = pDoc->getAngle();
	GLubyte alpha = pDoc->getAlpha();
	GLfloat thickness = pDoc->getThickness();
	double a = (angle * PI) / 180;
	double dx = maxSize * cos(a);
	double dy = maxSize * sin(a);

	SetColor(source);
	glVertex2i(target.x, target.y);
	glVertex2i(target.x + dx, target.y + dy);

}

void ScatteredLinesBrush::BrushBegin(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int thickness = pDoc->getThickness();

	glLineWidth((float)thickness);

	BrushMove(source, target);
}

void ScatteredLinesBrush::BrushMove(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;
	int size = pDoc->getSize();
	//int imgWid = pDoc->m_nPaintWidth;
	int random = rand() % 4 + 2;
	Point newSource, newTarget;
	int randomX = rand() % (size) + 1;
	int randomY = rand() % (size) + 1;
	int posnegX, posnegY;


	if (pDoc == NULL) {
		printf("LineBrush::BrushMove  document is NULL\n");
		return;
	}

	glBegin(GL_LINES);
	//glEnable(GL_BLEND);

	for (int i = 0; i < random; i++) {
		posnegX = rand() % 1;
		posnegY = rand() % 1;
		//positive XY
		if (posnegX == 0 && posnegY == 0) {
			newTarget.x = target.x + randomX;
			newTarget.y = target.y + randomY;
			newSource.x = source.x + randomX;
			newSource.y = source.y + randomY;
			drawLine(newSource, newTarget);
		}
		//Negative XY
		else if (posnegX == 1 && posnegY == 1){
			newTarget.x = target.x - randomX;
			newTarget.y = target.y - randomY;
			newSource.x = source.x - randomX;
			newSource.y = source.y - randomY;
			drawLine(newSource, newTarget);
		}
		//Neg X pos Y
		else if (posnegX == 1 && posnegY == 0) {
			newTarget.x = target.x - randomX;
			newTarget.y = target.y + randomY;
			newSource.x = source.x - randomX;
			newSource.y = source.y + randomY;
			drawLine(newSource, newTarget);
		}
		//Pos X neg Y
		else {
			newTarget.x = target.x + randomX;
			newTarget.y = target.y - randomY;
			newSource.x = source.x + randomX;
			newSource.y = source.y - randomY;
			drawLine(newSource, newTarget);
		}
	}

	glEnd();
}

void ScatteredLinesBrush::BrushEnd(const Point source, const Point target)
{
	// do nothing so far
}