//
// ImpBrush.cpp
//
// The implementation of virtual brush. All the other brushes inherit from it.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ImpBrush.h"

// Static class member initializations
int			ImpBrush::c_nBrushCount	= 0;
ImpBrush**	ImpBrush::c_pBrushes	= NULL;

ImpBrush::ImpBrush(ImpressionistDoc*	pDoc, 
				   char*				name) :
					m_pDoc(pDoc), 
					m_pBrushName(name)
{
}

//---------------------------------------------------
// Return m_pDoc, which connects the UI and brushes
//---------------------------------------------------
ImpressionistDoc* ImpBrush::GetDocument(void)
{
	return m_pDoc;
}

//---------------------------------------------------
// Return the name of the current brush
//---------------------------------------------------
char* ImpBrush::BrushName(void)
{
	return m_pBrushName;
}

//----------------------------------------------------
// set the color based on the source, target and alpha
//----------------------------------------------------
void ImpBrush::SetColor (const Point source, const Point target, const GLubyte alpha, unsigned char mask)
{
	ImpressionistDoc* pDoc = GetDocument();


	GLubyte sourceColor[3];
	GLubyte targetColor[3];
	

	memcpy (sourceColor, pDoc->GetOriginalPixel( source ), 3 );
	memcpy(targetColor, pDoc->GetTargetPixel(target), 3);


	GLubyte resultantColor[3];
	
	for (int i = 0; i <= 2; i++) {
		resultantColor[i] = (GLubyte)(((sourceColor[i] * alpha * mask) + (targetColor[i] * (255 - alpha * mask))) / 255);
	}
	
	glColor3ubv(resultantColor);
	

}

//----------------------------------------------------
// Set the color to paint with to the color at source,
// which is the coord at the original window to sample 
// the color from
//-
void ImpBrush::SetColor(const Point source)
{
	ImpressionistDoc* pDoc = GetDocument();


	GLubyte color[3];

	memcpy(color, pDoc->GetOriginalPixel(source), 3);

	glColor3ubv(color);

}