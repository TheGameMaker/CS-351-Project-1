//Clark Smiley
//G00891966
// CircleBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredCircles.h"
#include "math.h"

#define PI 3.14159265

extern float frand();

ScatteredCirclesBrush::ScatteredCirclesBrush(ImpressionistDoc* pDoc, char* name) :
	ImpBrush(pDoc, name)
{
}

void ScatteredCirclesBrush::drawCircle(const Point source, const Point target) {
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int radius = (pDoc->getSize() / 2);
	GLubyte alpha = pDoc->getAlpha();
	double twoPi = 2.0 * PI;

	SetColor(source);
	glVertex2f(target.x, target.y);
	for (int i = 0; i <= 20; i++) {
		glVertex2f((target.x + (radius * cos(i * twoPi / 20))), (target.y + (radius * sin(i * twoPi / 20))));
	}
}

void ScatteredCirclesBrush::BrushBegin(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int size = pDoc->getSize();

	BrushMove(source, target);
}

void ScatteredCirclesBrush::BrushMove(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;
	int size = pDoc->getSize();
	//int imgWid = pDoc->m_nPaintWidth;
	int random = rand() % 4 + 2;
	Point newSource, newTarget;
	int randomX = rand() % (size) + 1;
	int randomY = rand() % (size) + 1;
	int posnegX, posnegY;


	if (pDoc == NULL) {
		printf("LineBrush::BrushMove  document is NULL\n");
		return;
	}

	glBegin(GL_TRIANGLE_FAN);
	//glEnable(GL_BLEND);

	for (int i = 0; i < random; i++) {
		posnegX = rand() % 1;
		posnegY = rand() % 1;
		//positive XY
		if (posnegX == 0 && posnegY == 0) {
			newTarget.x = target.x + randomX;
			newTarget.y = target.y + randomY;
			newSource.x = source.x + randomX;
			newSource.y = source.y + randomY;
			drawCircle(newSource, newTarget);
		}
		//Negative XY
		else if (posnegX == 1 && posnegY == 1) {
			newTarget.x = target.x - randomX;
			newTarget.y = target.y - randomY;
			newSource.x = source.x - randomX;
			newSource.y = source.y - randomY;
			drawCircle(newSource, newTarget);
		}
		//Neg X pos Y
		else if (posnegX == 1 && posnegY == 0) {
			newTarget.x = target.x - randomX;
			newTarget.y = target.y + randomY;
			newSource.x = source.x - randomX;
			newSource.y = source.y + randomY;
			drawCircle(newSource, newTarget);
		}
		//Pos X neg Y
		else {
			newTarget.x = target.x + randomX;
			newTarget.y = target.y - randomY;
			newSource.x = source.x + randomX;
			newSource.y = source.y - randomY;
			drawCircle(newSource, newTarget);
		}
	}

	glEnd();
}

void ScatteredCirclesBrush::BrushEnd(const Point source, const Point target)
{
	// do nothing so far
}