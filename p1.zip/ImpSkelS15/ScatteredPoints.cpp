//
// PointBrush.cpp
//
// The implementation of Point Brush. It is a kind of ImpBrush. All your brush implementations
// will look like the file with the different GL primitive calls.
//

#include "impressionistDoc.h"
#include "impressionistUI.h"
#include "ScatteredPoints.h"

extern float frand();

ScatteredPointsBrush::ScatteredPointsBrush(ImpressionistDoc* pDoc, char* name) :
	ImpBrush(pDoc, name)
{
}

void ScatteredPointsBrush::BrushBegin(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int size = 1;



	glPointSize(1);

	BrushMove(source, target);
}

void ScatteredPointsBrush::BrushMove(const Point source, const Point target)
{
	ImpressionistDoc* pDoc = GetDocument();
	ImpressionistUI* dlg = pDoc->m_pUI;

	int size = pDoc->getSize();
	GLubyte alpha = pDoc->getAlpha();
	int tar_startX = target.x - (size / 2);
	int tar_startY = target.y - (size / 2);
	int src_startX = source.x - (size / 2);
	int src_startY = source.y - (size / 2);
	Point newTarget, newSource;

	unsigned char* mask = new unsigned char[size * size];
	memset(mask, 0, size * size);

	int random;
	
	//creates the mask for the points
	for (int l = 0; l < size * size; l++) {
		random = rand() % 8;
		if (random == 1) {
			mask[l] = 1;
		}
	}

	//pDoc->m_pPaintBitstart = Point((((centerMaskY * size) + centerMaskX) * 3) + mask);

	glColor3i(255, 0, 0);
	glVertex2d(source.x, source.y);



	if (pDoc == NULL) {
		printf("PointBrush::BrushMove  document is NULL\n");
		return;
	}

	glBegin(GL_POINTS);
	for (int k = 0; k < size; k++) {
		for (int p = 0; p < size; p++) {
				newTarget = Point(tar_startX + k, tar_startY + p);
				newSource = Point(src_startX + k, src_startY + p);
				SetColor(newSource, newTarget, alpha, mask[(p*size) + k]);
				glVertex2d(tar_startX + k, tar_startY + p);
		}

	}

	glEnd();
}

void ScatteredPointsBrush::BrushEnd(const Point source, const Point target)
{
	// do nothing so far
}